/**
 * Provides all classes for the DAO.
 *
 * @author Jean-Aymeric DIET jadiet@cesi.fr
 * @version 1.0
 */
package model.dao;
